class App:
    @classmethod
    def run(cls):
        pass
