from pinger.app.struct import App


def app():
    return App
