from pinger.config.struct import Config


def config():
    return Config.config()
